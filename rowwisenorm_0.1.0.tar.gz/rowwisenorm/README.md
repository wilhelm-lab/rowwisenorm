# rowwisenorm
Row-wise normalization R package

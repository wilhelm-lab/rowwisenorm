## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(rowwisenorm)

## -----------------------------------------------------------------------------
data_path1 <- system.file("extdata", "proteingroups.csv", package = "rowwisenorm")
data_path2 <- system.file("extdata", "experimentalDesignProcessed.txt", package = "rowwisenorm")

return_list <- read_files(data_path1, data_path2)

## -----------------------------------------------------------------------------
lowest_level_df <- return_list[["lowest_level_df"]]
exp_design <- return_list[["exp_design"]]
additional_cols <- return_list[["additional_cols"]]

## -----------------------------------------------------------------------------
lowest_level_df <- log2_transform(lowest_level_df)

## -----------------------------------------------------------------------------
lowest_level_df <- filter_rows(lowest_level_df)

## -----------------------------------------------------------------------------
lowest_level_df <- sum_normalize(lowest_level_df)

## -----------------------------------------------------------------------------
lowest_level_df_norm <- normalize_row(lowest_level_df, exp_design)

## -----------------------------------------------------------------------------
lowest_level_df_norm <- normalize_row(lowest_level_df, exp_design, ref=c("L", "M", "H"))

## -----------------------------------------------------------------------------
# lowest_level_df_norm <- normalize_row(lowest_level_df, exp_design, active = TRUE)

## -----------------------------------------------------------------------------
lowest_level_df_norm <- normalize_row(lowest_level_df, exp_design, refFunc = "sum")

## -----------------------------------------------------------------------------
write_outfile(lowest_level_df = lowest_level_df_norm)

## -----------------------------------------------------------------------------
write_outfile(lowest_level_df = lowest_level_df_norm, additional_cols = additional_cols)

## -----------------------------------------------------------------------------
write_outfile(lowest_level_df = lowest_level_df_norm, additional_cols = additional_cols, filename = "myfile", output_dir = "myout")

## -----------------------------------------------------------------------------
plot_results(lowest_level_df = lowest_level_df_norm, exp_design = exp_design)

## -----------------------------------------------------------------------------
plot_results(lowest_level_df = lowest_level_df_norm, exp_design = exp_design, main = "my_rowwisenorm_result", output_dir = "res")

## -----------------------------------------------------------------------------
plot_results(lowest_level_df = lowest_level_df_norm, exp_design = exp_design, output_dir = "res")

## -----------------------------------------------------------------------------
plot_results(lowest_level_df = lowest_level_df_norm, exp_design = exp_design, main = "my_rowwisenorm_result")


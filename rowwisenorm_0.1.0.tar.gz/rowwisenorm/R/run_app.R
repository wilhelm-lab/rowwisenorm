#' @title run_app
#'
#' @description
#' Execution of the shiny application. The application includes the performance of row-wise normalization,
#' as well as the total sum normalization, VST, VSN, quantile normalization, ComBat, and M-ComBat.
#'
#' @param local Boolean that states whether the app is called locally. If set, further options for manual downloads are included in the app.
#'
#' @return executes the shiny application
#'
#' @export
#'
#'

# THIS:
run_app <- function(local = FALSE) {
  original_wd <- getwd()
  print(original_wd)
  package_dir <- system.file(package = "rowwisenorm")
  package_source_path <- find.package("rowwisenorm", lib.loc = NULL)

  app_r_path <- file.path(package_dir, "shiny_app", "app.R")

  appDir <- system.file("shiny_app", "app.R", package = "rowwisenorm")

  print(package_dir)
  print(package_source_path)
  print(app_r_path)
  print(file.exists(app_r_path))
  setwd(package_dir)

  # Set the "local" option
  options(local = local)

  shiny::shinyAppDir(
    file.path("./R/shiny_app/"),  # assumes rowwisenorm as getwd()
  )

  setwd(original_wd)

}


# run_app <- function(local=F){
#   #runApp("./R/shiny_app/app.R")  # assumes current working directory to be rowwisenorm
#
#   #args <- if (local) "local" else ""  # *1 both ways is_local FALSE
#   args <- ifelse(local, "TRUE", "FALSE")  # *2 both ways is_local TRUE
#
#   #args <- as.character(local)
#   print(args)
#   print(class(args))
#
#   # options(shiny.args = args)
#   # runApp("./R/shiny_app/app.R")
#
#   shiny::shinyAppDir(
#     #system.file("./R/shiny_app", package = "rowwisenorm"),
#     file.path("./R/shiny_app/"),  # assumes rowwisenorm as getwd()
#     options = list(shiny.args = args)
#   )
# }

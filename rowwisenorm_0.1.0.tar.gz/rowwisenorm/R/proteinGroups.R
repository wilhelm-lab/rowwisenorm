#' MaxQuant output file proteinGroups.txt
#'
#' @docType data
#'
#' @usage read_files("proteinGroups.txt", "experimentalDesign.txt")
#'
#' @format An object of class \code{"data.frame"}
#' \describe{
#'  Contains all columns of the data.
#' }
#'
#' @references reference
#'
#' @keywords dataset
#'
